import mongoose, { Schema, Document } from 'mongoose';

interface ITask extends Document {
  _id: mongoose.Types.ObjectId;
  title: string;
  description: string;
  completed: boolean;
  dueDate: Date;
}

interface IUser extends Document {
  _id: mongoose.Types.ObjectId;
  fullName: string;
  email: string;
  password: string;
  tasks: ITask[];
}

const TaskSchema = new Schema({
  title: String,
  description: String,
  completed: { type: Boolean, default: false },
  dueDate: Date,
});

const UserSchema = new Schema({
  fullName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  tasks: [TaskSchema],
});

export default mongoose.model<IUser>('User', UserSchema);
