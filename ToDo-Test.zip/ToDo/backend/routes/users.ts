import express, { Request, Response } from 'express';

const router = express.Router();
import User from '../models/user';  
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';



router.post('/register', async (req: Request, res: Response) => {
  const { fullName, email, password, tasks } = req.body;

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    console.log("Registering user:", fullName, email);

    const user = new User({
      fullName,
      email,
      password: hashedPassword,
      tasks: tasks || [],  
    });

    await user.save();

    console.log("User registered:", user);
    res.status(201).json({ message: 'User registered successfully', user });
  } catch (err) {
    console.error("Error during registration:", err);
    res.status(500).json({ message: 'Something went wrong' });
  }
});

router.post('/login', async (req: Request, res: Response) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET as string, { expiresIn: '1h' });
    res.status(200).json({ token });
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong' });
  }
});



// Get a user by email
router.get('/user/:email', async (req: Request, res: Response) => {
  const { email } = req.params;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.status(200).json(user);
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong' });
  }
});

// Get a user by ID
router.get('/users/:id', async (req: Request, res: Response) => {
  const { id } = req.params;

  try {
    const user = await User.findById(id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.status(200).json(user);
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong' });
  }
});

// Get all users
router.get('/', async (req: Request, res: Response) => {
  try {
    const users = await User.find();
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong' });
  }
});


// Add a task to a user
router.post('/:id/tasks', async (req: Request, res: Response) => {
  const { id } = req.params;
  const { title, description, dueDate } = req.body;

  try {
    const user = await User.findById(id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const task = { title, description, completed: false, dueDate };
    user.tasks.push(task as any);  
    await user.save();

    res.status(201).json(user);
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong' });
  }
});

// Update a task for a user
router.put('/:userId/tasks/:taskId', async (req: Request, res: Response) => {
  const { userId, taskId } = req.params;
  const { title, description, completed, dueDate } = req.body;

  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const taskIndex = user.tasks.findIndex(task => task._id.toString() === taskId);
    if (taskIndex === -1) {
      return res.status(404).json({ message: 'Task not found' });
    }

    if (title !== undefined) user.tasks[taskIndex].title = title;
    if (description !== undefined) user.tasks[taskIndex].description = description;
    if (completed !== undefined) user.tasks[taskIndex].completed = completed;
    if (dueDate !== undefined) user.tasks[taskIndex].dueDate = new Date(dueDate);

    await user.save();
    res.status(200).json(user.tasks[taskIndex]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Something went wrong' });
  }
});

// Delete a task for a user
router.delete('/:userId/tasks/:taskId', async (req: Request, res: Response) => {
  const { userId, taskId } = req.params;

  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const taskIndex = user.tasks.findIndex(task => task._id.toString() === taskId);
    if (taskIndex === -1) {
      return res.status(404).json({ message: 'Task not found' });
    }

    user.tasks.splice(taskIndex, 1);
    await user.save();

    res.status(200).json(user);
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong' });
  }
});

// Get all tasks for a user
router.get('/:id/tasks', async (req: Request, res: Response) => {
  const { id } = req.params;

  try {
    const user = await User.findById(id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json(user.tasks);
  } catch (err) {
    res.status(500).json({ message: 'Something went wrong' });
  }
});

export default router;
