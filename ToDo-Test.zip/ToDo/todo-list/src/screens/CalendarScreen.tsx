import React, { useState, useEffect, useCallback } from 'react';
import { View, StyleSheet, Text, ScrollView } from 'react-native';
import { Calendar, DateObject } from 'react-native-calendars';
import axios from 'axios';
import { useFocusEffect } from '@react-navigation/native';


type Task = {
  _id: string;
  title: string;
  description: string;
  dueDate: string;
};

const CalendarScreen: React.FC<{ userId: string }> = ({ userId }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [markedDates, setMarkedDates] = useState<{ [key: string]: any }>({});
  const [selectedTasks, setSelectedTasks] = useState<Task[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>('');

  useFocusEffect(
    useCallback(() => {
      const fetchTasks = async () => {
        try {
        const response = await axios.get<Task[]>(`http://10.0.2.2:5000/api/${userId}/tasks`);
        const fetchedTasks = response.data;
        setTasks(fetchedTasks);
        
      const marks: { [key: string]: any } = {};
      fetchedTasks.forEach(task => {
        const dateKey = task.dueDate.split('T')[0];  
        marks[dateKey] = { marked: true }; 
      });
      setMarkedDates(marks);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };
  fetchTasks();
}, [userId])
);

const handleDayPress = (day: DateObject) => {
  const selectedTasks = tasks.filter(task => task.dueDate.split('T')[0] === day.dateString);
  setSelectedTasks(selectedTasks);
  setSelectedDate(day.dateString);
};

return (
  <View style={styles.container}>
    <Calendar
      markedDates={markedDates}
      onDayPress={handleDayPress}
    />
    <View style={styles.tasksContainer}>
      {selectedDate ? (
        <Text style={styles.selectedDateText}>Tasks for {selectedDate}:</Text>
      ) : null}
      <ScrollView>
        {selectedTasks.length === 0 ? (
          <Text style={styles.noTasksText}>No tasks for the selected date.</Text>
        ) : (
          selectedTasks.map(task => (
            <View key={task._id} style={styles.task}>
              <Text style={styles.taskTitle}>{task.title}</Text>
              <Text style={styles.taskDescription}>{task.description}</Text>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  </View>
);
};

const styles = StyleSheet.create({
container: {
  flex: 1,
  backgroundColor: '#f5f5f5',
},
tasksContainer: {
  padding: 16,
},
selectedDateText: {
  fontSize: 18,
  fontWeight: 'bold',
  marginBottom: 10,
},
noTasksText: {
  textAlign: 'center',
  marginTop: 16,
  fontSize: 16,
  color: '#888',
},
task: {
  padding: 16,
  marginBottom: 16,
  backgroundColor: '#fff',
  borderRadius: 8,
  shadowColor: '#000',
  shadowOpacity: 0.1,
  shadowOffset: { width: 0, height: 1 },
  shadowRadius: 8,
  elevation: 3,
},
taskTitle: {
  fontSize: 18,
  fontWeight: 'bold',
},
taskDescription: {
  marginTop: 4,
  fontSize: 16,
  color: '#555',
},
});

export default CalendarScreen;
