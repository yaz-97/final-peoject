import React, { useState, useEffect ,useCallback } from 'react';
import { View, Text, FlatList, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import { FAB, Dialog, Portal, Button, Provider , Checkbox} from 'react-native-paper';
import { Ionicons } from 'react-native-vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import axios from 'axios';
import { useFocusEffect } from '@react-navigation/native';

type Task = {
  _id: string;
  title: string;
  description: string;
  completed: boolean;
  dueDate: Date;
};

type User = {
  fullName: string;
  tasks: Task[];
};

const HomeScreen: React.FC<{ userId: string }> = ({ userId }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [dialogVisible, setDialogVisible] = useState<boolean>(false);
  const [newTaskTitle, setNewTaskTitle] = useState<string>('');
  const [newTaskDescription, setNewTaskDescription] = useState<string>('');
  const [newTaskDate, setNewTaskDate] = useState<Date>(new Date());
  const [showDatePicker, setShowDatePicker] = useState<boolean>(false);
  const [editTaskId, setEditTaskId] = useState<string | null>(null);
  const [username, setUsername] = useState<string | null>(null);

  const fetchUserData = async () => {
    try {
      if (userId) {
        const response = await axios.get<User>(`http://10.0.2.2:5000/api/users/${userId}`);
        const { fullName, tasks } = response.data;
        setUsername(fullName);
        setTasks(tasks.map(task => ({ ...task, dueDate: new Date(task.dueDate) })));
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch user data');
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchUserData();
    }, [userId])
  );

  const addTask = async () => {
    try {
      const newTask = {
        title: newTaskTitle,
        description: newTaskDescription,
        dueDate: newTaskDate.toISOString(),
        completed: false,
      };
      const response = await axios.post(`http://10.0.2.2:5000/api/${userId}/tasks`, newTask);
      fetchUserData();
      setDialogVisible(false);
      setNewTaskTitle('');
      setNewTaskDescription('');
      setNewTaskDate(new Date());
    } catch (error) {
      Alert.alert('Error', 'Failed to add task');
    }
  };

  const editTask = (task: Task) => {
    setEditTaskId(task._id);
    setNewTaskTitle(task.title);
    setNewTaskDescription(task.description);
    setNewTaskDate(new Date(task.dueDate));
    setDialogVisible(true);
  };

  const updateTask = async () => {
    if (editTaskId) {
      try {
        const updatedTask = {
          title: newTaskTitle,
          description: newTaskDescription,
          dueDate: newTaskDate.toISOString(),
        };
        await axios.put(`http://10.0.2.2:5000/api/${userId}/tasks/${editTaskId}`, updatedTask);
        const updatedTasks = tasks.map(task =>
          task._id === editTaskId ? { ...task, ...updatedTask, dueDate: new Date(updatedTask.dueDate) } : task
        );
        fetchUserData();
        setDialogVisible(false);
        setEditTaskId(null);
        setNewTaskTitle('');
        setNewTaskDescription('');
        setNewTaskDate(new Date());
      } catch (error) {
        Alert.alert('Error', 'Failed to update task');
      }
    }
  };

  const deleteTask = async (taskId: string) => {
    try {
      await axios.delete(`http://10.0.2.2:5000/api/${userId}/tasks/${taskId}`);
      setTasks(tasks.filter(task => task._id !== taskId));
    } catch (error) {
      Alert.alert('Error', 'Failed to delete task');
    }
  };

  const toggleTaskCompletion = async (taskId: string, completed: boolean) => {
    try {
      await axios.put(`http://10.0.2.2:5000/api/${userId}/tasks/${taskId}`, { completed });
      setTasks(tasks.map(task =>
        task._id === taskId ? { ...task, completed } : task
      ));
    } catch (error) {
      Alert.alert('Error', 'Failed to update task');
    }
  };

  const renderItem = ({ item }: { item: Task }) => {
    const dueDate = new Date(item.dueDate);

    return (
      <View style={styles.taskItem}>
        <View style={styles.taskHeader}>
          <Checkbox
            status={item.completed ? 'checked' : 'unchecked'}
            onPress={() => toggleTaskCompletion(item._id, !item.completed)}
          />
          <Text
            style={[
              styles.taskTitle,
              item.completed && styles.completedTitle
            ]}
          >
            {item.completed ? `✔️ ${item.title}` : item.title}
          </Text>
        </View>
        <Text style={styles.taskDescription}>{item.description}</Text>
        <Text style={styles.taskDate}>{dueDate.toDateString()}</Text>
        <View style={styles.taskActions}>
          <TouchableOpacity onPress={() => editTask(item)}>
            <Ionicons name="pencil" size={24} color="blue" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => deleteTask(item._id)}>
            <Ionicons name="trash" size={24} color="red" />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <Provider>
      <View style={styles.container}>
        <View style={styles.header}>
          {username ? <Text style={styles.headerText}>Welcome {username}</Text> : <Text>Loading...</Text>}
        </View>
        <FlatList
          data={tasks}
          renderItem={renderItem}
          keyExtractor={item => item._id}
          contentContainerStyle={styles.taskList}
          ListEmptyComponent={<Text style={styles.emptyText}>No tasks yet</Text>}
        />
        <FAB
          style={styles.fab}
          small
          icon={() => <Ionicons name="add" size={24} color="white" />}
          onPress={() => setDialogVisible(true)}
        />
        <Portal>
          <Dialog visible={dialogVisible} onDismiss={() => setDialogVisible(false)}>
            <Dialog.Title>{editTaskId ? 'Edit Task' : 'Add New Task'}</Dialog.Title>
            <Dialog.Content>
              <TextInput
                style={styles.input}
                placeholder="Title"
                value={newTaskTitle}
                onChangeText={setNewTaskTitle}
              />
              <TextInput
                style={styles.input}
                placeholder="Description"
                value={newTaskDescription}
                onChangeText={setNewTaskDescription}
              />
              <TouchableOpacity onPress={() => setShowDatePicker(true)}>
                <Text style={styles.dateText}>{newTaskDate.toDateString()}</Text>
              </TouchableOpacity>
              {showDatePicker && (
                <DateTimePicker
                  value={newTaskDate}
                  mode="date"
                  display="default"
                  onChange={(event, selectedDate) => {
                    setShowDatePicker(false);
                    if (selectedDate) {
                      setNewTaskDate(new Date(selectedDate));
                    }
                  }}
                  minimumDate={new Date()}
                />
              )}
            </Dialog.Content>
            <Dialog.Actions>
              <Button onPress={editTaskId ? updateTask : addTask}>
                {editTaskId ? 'Update' : 'Add'}
              </Button>
              <Button onPress={() => setDialogVisible(false)}>Cancel</Button>
            </Dialog.Actions>
          </Dialog>
        </Portal>
      </View>
    </Provider>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 16,
    backgroundColor: '#1D4ED8',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  taskList: {
    padding: 16,
  },
  taskItem: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
    elevation: 2,
    position: 'relative',
  },
  taskTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  taskDescription: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  }, completedTitle: {
    textDecorationLine: 'line-through',  
    color: 'gray',
  },
  taskDate: {
    fontSize: 12,
    color: '#999',
    marginTop: 8,
  },
  taskActions: {
    position: 'absolute',
    right: 16,
    top: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: 60,
  }, taskHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  fab: {
    position: 'absolute',
    right: 16,
    bottom: 16,
    backgroundColor: '#1D4ED8',
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 32,
    fontSize: 18,
    color: 'gray',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 8,
    marginTop: 8,
    backgroundColor: '#fff',
  },
  dateText: {
    fontSize: 16,
    color: '#ff0000',
    marginTop: 16,
  },
});

export default HomeScreen;
