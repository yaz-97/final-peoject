import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Alert, Image, TouchableOpacity } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import bcrypt from 'bcryptjs';


type RootStackParamList = {
  Login: undefined;
  Main: { userId: string };
  Signup: undefined;
};

type LoginScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Login'>;
type LoginScreenRouteProp = RouteProp<RootStackParamList, 'Login'>;

type Props = {
  navigation: LoginScreenNavigationProp;
  route: LoginScreenRouteProp;
};

const LoginScreen: React.FC<any> = ({ navigation, onLoginSuccess }) => {
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');

  const validateEmail = (email: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const checkUserExists = async (email: string) => {
    try {
      const response = await axios.get(`http://10.0.2.2:5000/api/?email=${encodeURIComponent(email)}`);
      console.log("----"+response.data);
      console.log('User Data:', JSON.stringify(response.data, null, 2));

      return response.data;
    } catch (error) {
      Alert.alert('Error', 'Unable to check if user exists');
      return null;
    }
  };

  const handleLogin = async () => {
    if (!validateEmail(email)) {
      Alert.alert('Login Failed', 'Invalid email format');
      return;
    }

    console.log("GJG");

    try {
      const users = await checkUserExists(email);
      console.log('Users:', JSON.stringify(users, null, 2));
      const user = users.find((user: any) => user.email === email);
      console.log('Found User:', JSON.stringify(user, null, 2));

      
      console.log("KKK");

      if (!user) {
        Alert.alert('Login Failed', 'User does not exist');
        alert('Login Failed User does not exist');

        return;
      }

      console.log('User Password:', user.password);

      const isMatch = await bcrypt.compare(password, user.password);


      console.log(".." + isMatch + " ..  " + password)
      console.log("GJG");
      if (!isMatch) {
        Alert.alert('Login Failed', 'Invalid email or password');
        alert('Login FailedInvalid email or password');

        return;
      }

      console.log(">>>>" +user._id);
      onLoginSuccess(user._id);

      
    } catch (error) {
      Alert.alert('Login Failed', 'An error occurred during login');
    }
  };

  return (
    <View style={styles.container}>
      <Image source={require('../assets/logo.png')} style={styles.logo} />
      <Text style={styles.title}>Welcome Back!</Text>
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        placeholderTextColor="#a9a9a9"
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        placeholderTextColor="#a9a9a9"
      />
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.link} onPress={() => navigation.navigate('Signup')}>
        <Text style={styles.linkText}>Don't have an account? Sign Up</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  logo: {
    width: 200,
    height: 200,
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    marginBottom: 24,
    color: '#333',
    fontWeight: 'bold',
  },
  input: {
    height: 50,
    width: '90%',
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 25,
    paddingHorizontal: 16,
    marginBottom: 16,
    backgroundColor: '#fff',
    color: '#333',
  },
  button: {
    height: 50,
    width: '90%',
    backgroundColor: '#6200ee',
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  link: {
    marginTop: 16,
  },
  linkText: {
    color: '#6200ee',
    fontSize: 16,
  },
});

export default LoginScreen;
