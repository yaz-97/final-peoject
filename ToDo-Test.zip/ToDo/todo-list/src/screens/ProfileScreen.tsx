import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, Alert, TouchableOpacity, Dimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { PieChart } from 'react-native-chart-kit';
import { useFocusEffect } from '@react-navigation/native';

interface Task {
  title: string;
  description: string;
  completed: boolean;
  _id: string;
  dueDate?: string;
}

interface UserData {
  _id: string;
  fullName: string;
  email: string;
  password: string;
  tasks: Task[];
  __v: number;
}
const ProfileScreen: React.FC<{ userId: string }> = ({ userId }) => {
  const [userData, setUserData] = useState<UserData | null>(null);
  const [tasksData, setTasksData] = useState<{ completed: number; notCompleted: number }>({ completed: 0, notCompleted: 0 });
  const navigation = useNavigation();

  useFocusEffect(
    useCallback(() => {
      fetchUserData();
    }, [userId])
  );

  const fetchUserData = async () => {
    try {
      if (userId) {
        const response = await fetch(`http://10.0.2.2:5000/api/users/${userId}`);
        if (response.ok) {
          const data: UserData = await response.json();
          setUserData(data);
          calculateTaskData(data.tasks);
        } else {
          Alert.alert('Error', 'User not found');
        }
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch user data');
    }
  };

  const calculateTaskData = (tasks: Task[]) => {
    const completed = tasks.filter(task => task.completed).length;
    const notCompleted = tasks.length - completed;
    setTasksData({ completed, notCompleted });
  };

  const handleLogout = () => {
    //setUserData(null);
    navigation.navigate('Login');
  };

  const handleChartPress = () => {
    fetchUserData();
  };

  if (!userData) {
    return (
      <View style={styles.container}>
        <Text>Loading user data...</Text>
      </View>
    );
  }

  const chartData = [
    {
      name: 'Completed',
      count: tasksData.completed,
      color: '#2563eb',
      legendFontColor: '#2563eb',
      legendFontSize: 15,
      onPress: handleChartPress,
    },
    {
      name: 'Not Completed',
      count: tasksData.notCompleted,
      color: '#f29aa9',
      legendFontColor: '#f29aa9',
      legendFontSize: 15,
      onPress: handleChartPress,
    },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.chartContainer}>
        <View style={styles.chartWrapper}>
          <PieChart
            data={chartData}
            width={Dimensions.get('window').width - 40}
            height={220}
            chartConfig={{
              backgroundColor: '#f8fafc',
              backgroundGradientFrom: '#f8fafc',
              backgroundGradientTo: '#f8fafc',
              color: (opacity = 1) => `rgba(31, 41, 55, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(31, 41, 55, ${opacity})`,
            }}
            accessor="count"
            backgroundColor="transparent"
            paddingLeft="15"
            absolute
            style={styles.chart}
            center={[Dimensions.get('window').width / 4 - 20, 10]} 

            hasLegend={false}           />
        </View>


        <View style={styles.legendContainer}>
          {chartData.map((item, index) => (
            <View key={index} style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: item.color }]} />
              <Text style={styles.legendText}>{item.name}: {item.count}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.userDetailsContainer}>
        <Text style={styles.userDetailText}>Full Name:</Text>
        <View style={styles.userDetailBox}>
          <Text style={styles.userDetailValue}>{userData.fullName}</Text>
        </View>
        <Text style={styles.userDetailText}>Email:</Text>
        <View style={styles.userDetailBox}>
          <Text style={styles.userDetailValue}>{userData.email}</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutButtonText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    padding: 20,
  },
  chartContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  chartWrapper: {
    backgroundColor: '#ffffff',
    borderRadius: 15,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    overflow: 'hidden',
    alignItems: 'center',
    padding: 15, 
  },
  chart: {
    marginBottom: 20,
  },
  legendContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginTop: 10,
    width: '100%',  
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  legendColor: {
    width: 15,
    height: 15,
    borderRadius: 7.5,
    marginRight: 5,
  },
  legendText: {
    fontSize: 15,
    color: '#374151',
  },
  userDetailsContainer: {
    marginBottom: 20,
    width: '100%',  
    alignItems: 'flex-start',  
  },
  userDetailText: {
    fontSize: 16,
    color: '#6b7280', 
    fontWeight: '500',
    marginBottom: 5,  
  },
  userDetailBox: {
    width: '100%',
    padding: 10,
    borderRadius: 8,
    backgroundColor: '#ffffff',
    borderColor: '#d1d5db', 
    borderWidth: 1,
    marginBottom: 15,  
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  userDetailValue: {
    fontSize: 18,
    color: '#1F2937',  
    fontWeight: '700',
  },
  loadingText: {
    fontSize: 18,
    color: '#9ca3af',
  },
  logoutButton: {
    backgroundColor: '#1D4ED8',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 8,
  },
  logoutButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '700',
  },
});


export default ProfileScreen;
