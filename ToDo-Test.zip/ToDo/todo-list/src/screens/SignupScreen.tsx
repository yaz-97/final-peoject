import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, Image, TouchableOpacity } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import axios from 'axios';

type RootStackParamList = {
    Login: undefined;
    Main: { userId: string };
    Signup: undefined;
};

type SignupScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Signup'>;
type SignupScreenRouteProp = RouteProp<RootStackParamList, 'Signup'>;

type Props = {
    navigation: SignupScreenNavigationProp;
    route: SignupScreenRouteProp;
};

const SignupScreen: React.FC<Props> = ({ navigation }) => {
    const [fullName, setFullName] = useState<string>('');
    const [email, setEmail] = useState<string>('');
    const [password, setPassword] = useState<string>('');
    const [confirmPassword, setConfirmPassword] = useState<string>('');
    const [tasks, setTasks] = useState<Array<{ id: string; title: string; description: string; date: Date }>>([]);

    const validateEmail = (email: string) => {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    };

    const handleSignup = async () => {
        if (password !== confirmPassword) {
            Alert.alert('Signup Failed', 'Passwords do not match');
            return;
        }

        if (email && password && fullName) {
            try {
                console.log("Attempting signup:", fullName, email, password, tasks);
                const response = await axios.post('http://10.0.2.2:5000/api/register', {
                    fullName,
                    email,
                    password,
                    tasks, 
                });
                console.log("n");
                console.log("Signup response:", response.data);
                navigation.navigate('Login');
            } catch (error) {
                console.error("Signup error:", error);
                Alert.alert('Signup Failed', 'An error occurred during signup');
            }
        } else {
            Alert.alert('Signup Failed', 'Please enter all fields');
        }
    };

    return (
        <View style={styles.container}>
            <Image source={require('../assets/logo.png')} style={styles.logo} />
            <Text style={styles.title}>Create Account</Text>
            <TextInput
                style={styles.input}
                placeholder="Full Name"
                value={fullName}
                onChangeText={setFullName}
                autoCapitalize="words"
                placeholderTextColor="#a9a9a9"
            />
            <TextInput
                style={styles.input}
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                placeholderTextColor="#a9a9a9"
            />
            <TextInput
                style={styles.input}
                placeholder="Password"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                placeholderTextColor="#a9a9a9"
            />
            <TextInput
                style={styles.input}
                placeholder="Confirm Password"
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry
                placeholderTextColor="#a9a9a9"
            />
            <TouchableOpacity style={styles.button} onPress={handleSignup}>
                <Text style={styles.buttonText}>Signup</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.link} onPress={() => navigation.navigate('Login')}>
                <Text style={styles.linkText}>Already have an account? Login</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 16,
        backgroundColor: '#f5f5f5',
    },
    logo: {
        width: 250,
        height: 250,
        marginBottom: 32,
    },
    title: {
        fontSize: 28,
        marginBottom: 24,
        color: '#333',
        fontWeight: 'bold',
    },
    input: {
        height: 50,
        width: '90%',
        borderColor: '#ddd',
        borderWidth: 1,
        borderRadius: 25,
        paddingHorizontal: 16,
        marginBottom: 16,
        backgroundColor: '#fff',
        color: '#333',
    },
    button: {
        height: 50,
        width: '90%',
        backgroundColor: '#6200ee',
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 16,
    },
    buttonText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
    link: {
        marginTop: 16,
    },
    linkText: {
        color: '#6200ee',
        fontSize: 16,
    },
});

export default SignupScreen;
